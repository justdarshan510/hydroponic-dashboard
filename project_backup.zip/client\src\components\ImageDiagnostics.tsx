import { useMemo, useRef, useState } from 'react';
import { AlertTriangle, Camera, Check, Loader2, Upload, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as ss from 'simple-statistics';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { REMEDIAL_MEASURES } from '@/lib/mockData';
import { extractMetadataFromImageBlob, type HydroponicImageRecord } from '@/lib/hydroponicMetadata';

import healthyLeaf from '@assets/generated_images/close_up_of_a_healthy_green_plant_leaf.png';
import kDefLeaf from '@assets/generated_images/plant_leaf_showing_potassium_deficiency_symptoms.png';

interface ImageDiagnosticsProps {
  data: HydroponicImageRecord[];
}

const FEATURE_FIELDS = [
  { key: 'Mean_R', label: 'red value' },
  { key: 'Mean_G', label: 'green value' },
  { key: 'Mean_B', label: 'blue value' },
  { key: 'Brightness', label: 'brightness' },
  { key: 'Green_Coverage_Pct', label: 'green area' },
  { key: 'Contrast', label: 'contrast' },
] as const;

type FieldKey = (typeof FEATURE_FIELDS)[number]['key'];

interface DiagnosticResult {
  class: string;
  confidence: number;
  explanation: string;
  featureNotes: string[];
}

function round(value: number, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function normalizeValue(value: number, mean: number, deviation: number) {
  if (!Number.isFinite(value)) return 0;
  if (!Number.isFinite(deviation) || deviation === 0) return value - mean;
  return (value - mean) / deviation;
}

async function imageUrlToBlob(imageUrl: string) {
  const response = await fetch(imageUrl);
  return response.blob();
}

export function ImageDiagnostics({ data }: ImageDiagnosticsProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DiagnosticResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const model = useMemo(() => {
    const labeledData = data.filter((record) => record.Class_Label !== 'Unknown');
    if (labeledData.length < 5) return null;

    const featureStats = Object.fromEntries(
      FEATURE_FIELDS.map(({ key }) => {
        const series = labeledData.map((record) => Number(record[key]));
        return [
          key,
          {
            mean: ss.mean(series),
            deviation: ss.standardDeviation(series) || 1,
          },
        ];
      }),
    ) as Record<FieldKey, { mean: number; deviation: number }>;

    const samples = labeledData.map((record) => ({
      label: record.Class_Label,
      raw: record,
      values: Object.fromEntries(
        FEATURE_FIELDS.map(({ key }) => [
          key,
          normalizeValue(Number(record[key]), featureStats[key].mean, featureStats[key].deviation),
        ]),
      ) as Record<FieldKey, number>,
    }));

    return {
      featureStats,
      samples,
      k: Math.min(5, Math.max(3, Math.floor(Math.sqrt(samples.length)))),
      classCentroids: Array.from(
        labeledData.reduce((map, record) => {
          if (!map.has(record.Class_Label)) map.set(record.Class_Label, []);
          map.get(record.Class_Label)?.push(record);
          return map;
        }, new Map<string, HydroponicImageRecord[]>()),
      ).map(([label, records]) => ({
        label,
        centroid: Object.fromEntries(
          FEATURE_FIELDS.map(({ key }) => [key, ss.mean(records.map((record) => Number(record[key])))]),
        ) as Record<FieldKey, number>,
      })),
    };
  }, [data]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    setUploadedFile(file);
    setSelectedImage(URL.createObjectURL(file));
    setResult(null);
  };

  const handleDemoImage = (imageUrl: string) => {
    setUploadedFile(null);
    setSelectedImage(imageUrl);
    setResult(null);
  };

  const analyzeImage = async () => {
    if (!selectedImage || !model) return;

    setIsAnalyzing(true);

    try {
      const blob = uploadedFile ?? await imageUrlToBlob(selectedImage);
      const metadata = await extractMetadataFromImageBlob(
        blob,
        uploadedFile?.name ?? 'demo-image.png',
        uploadedFile?.name ?? selectedImage,
      );

      const normalizedInput = Object.fromEntries(
        FEATURE_FIELDS.map(({ key }) => [
          key,
          normalizeValue(Number(metadata[key]), model.featureStats[key].mean, model.featureStats[key].deviation),
        ]),
      ) as Record<FieldKey, number>;

      const neighbors = model.samples
        .map((sample) => {
          const distance = Math.sqrt(
            FEATURE_FIELDS.reduce((accumulator, { key }) => {
              return accumulator + (normalizedInput[key] - sample.values[key]) ** 2;
            }, 0),
          );

          return { label: sample.label, distance };
        })
        .sort((a, b) => a.distance - b.distance)
        .slice(0, model.k);

      const votes = neighbors.reduce((map, neighbor) => {
        const weight = 1 / (neighbor.distance + 1e-6);
        map.set(neighbor.label, (map.get(neighbor.label) ?? 0) + weight);
        return map;
      }, new Map<string, number>());

      const sortedVotes = Array.from(votes.entries()).sort((a, b) => b[1] - a[1]);
      const predictedClass = sortedVotes[0]?.[0] ?? 'Unknown';
      const totalVote = sortedVotes.reduce((sum, [, weight]) => sum + weight, 0);
      const confidence = totalVote > 0 ? round(((sortedVotes[0]?.[1] ?? 0) / totalVote) * 100, 1) : 0;
      const matchingNeighbors = neighbors.filter((neighbor) => neighbor.label === predictedClass).length;

      const centroid = model.classCentroids.find((entry) => entry.label === predictedClass)?.centroid;
      const featureNotes = centroid
        ? FEATURE_FIELDS.slice(0, 3).map(({ key, label }) => {
            const value = Number(metadata[key]);
            const delta = round(value - centroid[key], key === 'Green_Coverage_Pct' ? 1 : 2);
            const relation = delta >= 0 ? 'higher' : 'lower';
            return `The image has ${relation} ${label} than the average ${predictedClass} sample by ${Math.abs(delta)}.`;
          })
        : [];

      const explanation =
        predictedClass === 'Unknown'
          ? 'The uploaded image could not be matched reliably with the current dataset.'
          : `${matchingNeighbors} of the ${model.k} closest dataset images belong to ${predictedClass}, so this leaf most closely matches that deficiency pattern.`;

      setResult({
        class: predictedClass,
        confidence,
        explanation,
        featureNotes,
      });
    } catch (error) {
      console.error(error);
      setResult({
        class: 'Unknown',
        confidence: 0,
        explanation: 'The image could not be analyzed. Please upload a clearer single-leaf image.',
        featureNotes: [],
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const remedial = result ? REMEDIAL_MEASURES[result.class as keyof typeof REMEDIAL_MEASURES] : null;

  return (
    <div className="mx-auto max-w-6xl space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-10">
      <div className="space-y-4 text-center">
        <h2 className="text-4xl font-bold tracking-tight text-slate-900">Image Diagnostics</h2>
        <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
           Visual leaf analysis against your dataset. Upload a plant specimen for real-time deficiency classification and remedial guidance.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <Card className="border-none shadow-sm ring-1 ring-slate-100 bg-white rounded-[2rem] overflow-hidden">
          <CardHeader className="p-8 pb-4">
            <CardTitle className="text-xl">Image Upload</CardTitle>
            <CardDescription>Support for high-resolution JPG or PNG specimens.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8 p-8 pt-4">
            <div
              className={`
                cursor-pointer rounded-[1.5rem] border-2 border-dashed p-12 text-center transition-all duration-300
                ${selectedImage ? 'border-primary/40 bg-slate-50/50' : 'border-slate-200 bg-slate-50/10 hover:border-primary/40 hover:bg-slate-50/50'}
              `}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleFileChange}
              />

              {selectedImage ? (
                <div className="group relative aspect-video w-full overflow-hidden rounded-[1rem] shadow-sm">
                  <img src={selectedImage} alt="Preview" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <p className="text-white font-bold text-sm bg-black/40 px-4 py-2 rounded-full">Change Specimen</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6 py-10">
                  <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-white shadow-sm ring-1 ring-slate-100">
                    <Upload className="h-10 w-10 text-slate-300" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-lg font-bold text-slate-900">Select plant specimen</p>
                    <p className="text-sm text-slate-400 font-medium">Click or drag image here</p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-3">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 text-center mb-1">Interactive Demo Cases</div>
              <div className="flex justify-center gap-4">
                <Button variant="outline" className="rounded-xl border-slate-200 bg-white hover:bg-slate-50" size="sm" onClick={() => handleDemoImage(healthyLeaf)}>
                  Case: Healthy
                </Button>
                <Button variant="outline" className="rounded-xl border-slate-200 bg-white hover:bg-slate-50" size="sm" onClick={() => handleDemoImage(kDefLeaf)}>
                  Case: Potassium Def.
                </Button>
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-8 pt-0">
            <Button 
              className="w-full h-14 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl shadow-xl transition-all active:scale-95" 
              size="lg" 
              onClick={analyzeImage} 
              disabled={!selectedImage || isAnalyzing || !model}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="mr-3 h-5 w-5 animate-spin" />
                  Processing Features...
                </>
              ) : (
                <>
                  <Camera className="mr-3 h-5 w-5" />
                  Initialize Classification
                </>
              )}
            </Button>
          </CardFooter>
        </Card>

        <div className="space-y-6">
          {isAnalyzing && (
            <Card className="border-primary/20">
              <CardContent className="space-y-4 py-10">
                <div className="mb-2 flex justify-between text-sm font-medium">
                  <span>Comparing image with dataset samples...</span>
                  <span className="text-muted-foreground">78%</span>
                </div>
                <Progress value={78} className="h-2" />
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <div className="h-20 animate-pulse rounded bg-muted delay-75" />
                  <div className="h-20 animate-pulse rounded bg-muted delay-150" />
                  <div className="h-20 animate-pulse rounded bg-muted delay-300" />
                </div>
              </CardContent>
            </Card>
          )}

          {!isAnalyzing && result && (
            <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <Card className="overflow-hidden border-none shadow-xl ring-1 ring-slate-100 bg-white rounded-[2.5rem]">
                <div className={`h-3 w-full ${result.class === 'Healthy' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                <CardHeader className="p-10 pb-6 border-none">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl font-bold">Inference Detail</CardTitle>
                    <Badge className={cn(
                      "px-4 py-1 h-8 text-xs font-bold uppercase tracking-wider rounded-full border-none",
                      result.class === 'Healthy' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                    )}>
                      {result.class === 'Unknown' ? 'Low Match' : `${result.confidence}% Match`}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-10 pt-0 space-y-10">
                  <div className="flex items-center gap-6">
                    <div className={cn(
                      "h-20 w-20 rounded-[2rem] flex items-center justify-center shadow-inner",
                      result.class === 'Healthy' ? "bg-emerald-50" : "bg-rose-50"
                    )}>
                      {result.class === 'Healthy' ? <Check className="h-10 w-10 text-emerald-500" /> : <AlertTriangle className="h-10 w-10 text-rose-500" />}
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-5xl font-black tracking-tighter text-slate-900">{result.class}</h3>
                      <p className="text-sm font-medium text-slate-400 leading-relaxed">{result.explanation}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm ring-1 ring-slate-100 bg-white rounded-[2rem]">
                <CardHeader className="px-8 pt-8 pb-4">
                  <CardTitle className="text-base font-bold">Feature Rationalization</CardTitle>
                  <CardDescription>Logical mapping against dataset distribution.</CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <div className="space-y-3">
                    {result.featureNotes.length > 0 ? (
                      result.featureNotes.map((note) => (
                        <div key={note} className="rounded-2xl bg-slate-50 border border-slate-100 p-4 text-xs font-medium text-slate-600 leading-relaxed shadow-sm transition-transform hover:scale-[1.02]">
                          {note}
                        </div>
                      ))
                    ) : (
                      <div className="rounded-2xl bg-slate-50 border border-slate-100 p-8 text-center text-xs font-semibold text-slate-400 italic">
                        No distinct feature outliers detected.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {remedial && (
                <Card className="border-none shadow-xl ring-1 ring-slate-100 bg-white rounded-[2.5rem] overflow-hidden">
                  <div className="bg-slate-900 p-10 text-white">
                    <CardTitle className="text-2xl font-black mb-2 tracking-tight">Industrial Remediation Plan</CardTitle>
                    <CardDescription className="text-slate-400 font-medium">Professional guidance for crop corrective action.</CardDescription>
                  </div>
                  <CardContent className="p-10 pt-8">
                    <div className="space-y-10">
                      <div>
                        <h4 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                          <div className="h-6 w-1 bg-primary rounded-full" />
                          {remedial.title}
                        </h4>
                        <div className="grid gap-4">
                          {remedial.actions.map((action, index) => (
                            <div key={index} className="group flex items-start gap-5 p-6 rounded-[1.5rem] bg-slate-50 transition-all hover:bg-white hover:shadow-md border border-transparent hover:border-slate-100">
                              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white shadow-sm ring-1 ring-slate-100 text-sm font-bold text-primary group-hover:scale-110 transition-transform">
                                {index + 1}
                              </span>
                              <span className="text-sm font-medium text-slate-600 leading-relaxed pt-2">{action}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {!isAnalyzing && !result && (
            <div className="flex h-full min-h-[500px] flex-col items-center justify-center rounded-[2.5rem] border-2 border-dashed border-slate-100 p-12 text-center bg-slate-50/20">
              <Camera className="mb-8 h-24 w-24 text-slate-200" />
              <h3 className="text-2xl font-bold text-slate-900">System Ready for Diagnosis</h3>
              <p className="max-w-xs mt-3 text-slate-400 font-medium">Upload a plant specimen image on the left to begin holographic feature mapping.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
